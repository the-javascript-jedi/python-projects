Starting HTML and CSS files for the Full Stack Todos application.
